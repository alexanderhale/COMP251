package A1;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import A1.GraderManager.Mark;

public class Grader {

	
	public static void main(String[] args) {
		
		
		
		System.out.println("Test open addressing probe");
		GraderManager probeGrade = new GraderManager();
		Open_Addressing addressing = new Open_Addressing(10, 0);
		
		probeGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing default case");
			return addressing.probe(1, 0)==30? new Mark(1, 1) : new Mark(0, 1);
		});
		probeGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing i");
			return addressing.probe(1, 1)==31? new Mark(1, 1) : new Mark(0, 1);
		});
		probeGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing i modulo");
			return addressing.probe(1, 3)==1? new Mark(1, 1) : new Mark(0, 1);
		});
		probeGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing different key 1");
			return addressing.probe(2, 0)==28? new Mark(1, 1) : new Mark(0, 1);
		});
		probeGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing different key 2");
			return addressing.probe(4, 0)==25? new Mark(1, 1) : new Mark(0, 1);
		});
		probeGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing overflow ");
			return addressing.probe(Integer.MAX_VALUE, 0)==1? new Mark(1, 1) : new Mark(0, 1);
		});
		Mark probeTotal = probeGrade.grade();
		probeGrade.displayGrades();
		System.out.println("Probe "+probeGrade.grade);
		
		System.out.println("Test chaining probe");
		GraderManager chainGrade = new GraderManager();
		Chaining chaining = new Chaining(10, 0);
		chainGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing default case "+chaining.chain(1));
			return chaining.chain(1)==30? new Mark(1, 1) : new Mark(0, 1);
		});
		chainGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing overflow case "+chaining.chain(Integer.MAX_VALUE));
			return chaining.chain(Integer.MAX_VALUE)==1? new Mark(1, 1) : new Mark(0, 1);
		});
		chainGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing different key ");
			return chaining.chain(4)==25? new Mark(1, 1) : new Mark(0, 1);
		});
		chainGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing different key ");
			return chaining.chain(8)==19? new Mark(1, 1) : new Mark(0, 1);
		});
		chainGrade.addGrading((messages, i)-> {
			messages.set(i, "Testing different key ");
			return chaining.chain(16)==6? new Mark(1, 1) : new Mark(0, 1);
		});
		chainGrade.grade();
		chainGrade.displayGrades();
		System.out.println("Chain "+chainGrade.grade);
		
		System.out.println("Test insert key for chaining");
		GraderManager chainingInsertGrade = new GraderManager();
		Chaining chainInsert = new Chaining(10, 0);
		
		chainingInsertGrade.addGrading((messages, i)->{
			messages.set(i, "Testing insert key into arraylist");
			int initsize = chaining.Table.get(chaining.chain(0)).size();
			chainInsert.insertKey(0);
			return chainInsert.Table.get(chaining.chain(0)).size()-initsize == 1? new Mark(1,1) : new Mark(0, 1);
		});
		chainingInsertGrade.addGrading((messages, i)->{
			messages.set(i, "Testing insert at end of chain");
			chainInsert.insertKey(1);
			chainInsert.insertKey(81);
			// first element should be 1 and the second should be 81
			ArrayList<Integer> hash81 = chainInsert.Table.get(chaining.chain(81));
			return  ((hash81.get(0) == 1 && hash81.size()==2 && hash81.get(1) == 81) || (hash81.get(0) == 81 && hash81.size()==2 && hash81.get(1) == 1)) ? 
							new Mark(1,1) : new Mark(0, 1);
		});
		chainingInsertGrade.addGrading((messages, i)->{
			messages.set(i, "Testing collisions");
			chainInsert.insertKey(32);
			chainInsert.insertKey(52);
			int collisions = chainInsert.insertKey(72);
			return  collisions == 2 ? new Mark(1,1) : new Mark(0, 1);
		});
		
		chainingInsertGrade.grade();
		chainingInsertGrade.displayGrades();
		System.out.println("Chain insert "+chainingInsertGrade.grade);
		
		System.out.println("Test insert key for open addressing");
		GraderManager openInsertGrade = new GraderManager();
		Open_Addressing openInsert = new Open_Addressing(10, 0);
		openInsertGrade.addGrading((messages, i)->{
			messages.set(i, "Testing insert key ");
			openInsert.insertKey(0);
			return openInsert.Table[openInsert.probe(0, 0)] == 0? new Mark(1,1): new Mark(0, 1);
		});
		Open_Addressing openInsertFull = new Open_Addressing(10, 0);
		openInsertGrade.addGrading((messages, i)->{
			messages.set(i, "Testing insert key when full ");
			IntStream.range(0, openInsertFull.Table.length).forEach(n->openInsertFull.insertKey(n));
			openInsertFull.insertKey(33);
			return Arrays.stream(openInsertFull.Table)
							.mapToObj(n->n!=33)
							.reduce((acc,x)->acc&&x).get() ? new Mark(1,1): new Mark(0, 1);
		});
		openInsertGrade.addGrading((messages, i)->{
			messages.set(i, "Testing collisions ");
			openInsert.insertKey(32);
			openInsert.insertKey(52);
			openInsert.insertKey(72);
			int collisions = openInsert.insertKey(92);
			return collisions==3? new Mark(1,1): new Mark(0, 1);
		});
		
		
		openInsertGrade.grade();
		openInsertGrade.displayGrades();
		System.out.println("Open insert "+openInsertGrade.grade);
		
		
		System.out.println("Test remove key for open addressing");
		GraderManager openRemoveGrade = new GraderManager();
		Open_Addressing openRemove = new Open_Addressing(10, 0);
		openRemoveGrade.addGrading((messages,i)->{
			messages.set(i, "Testing remove key default case");
			openInsert.removeKey(0);
			return openInsert.Table[0]!=0 ? new Mark(1, 1): new Mark(0, 1);
		});
		
		openRemoveGrade.addGrading((messages,i)->{
			messages.set(i, "Testing remove key more than 1 collided case");
			openInsert.removeKey(52);
			return openInsert.Table[14]!=52 ? new Mark(1, 1): new Mark(0, 1);
		});
		
		openRemoveGrade.addGrading((messages,i)->{
			messages.set(i, "Testing removing key with more than 1 collided then adding a key back");
			openRemove.insertKey(32);
			openRemove.insertKey(52);
			openRemove.insertKey(72);
			openRemove.removeKey(52);
			openRemove.insertKey(92);
			return openRemove.Table[13]==32 &&
					openRemove.Table[14]==92 &&
					openRemove.Table[15]==72? new Mark(1, 1): new Mark(0, 1);
		});
		openRemoveGrade.addGrading((messages,i)->{
			messages.set(i, "Testing collisions");
			openInsert.insertKey(69);
			openInsert.insertKey(89);
			openInsert.insertKey(109);
			openInsert.insertKey(129);
			int collisions = openInsert.removeKey(89);
			return collisions == 1? new Mark(1, 1): new Mark(0, 1);
		});
		
		
		openRemoveGrade.grade();
		openRemoveGrade.displayGrades();
		System.out.println("Open remove "+openRemoveGrade.grade);
		
		System.out.println("Test main");
		GraderManager mainGrade = new GraderManager();
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("n_comparison.csv")));
			String line;
			List<String> lines = new ArrayList<>();
			while((line=br.readLine())!=null) {
				lines.add(line);
			}
			mainGrade.addGrading((messages, i)->{
				messages.set(i, "Test n_comparison chain");
				return lines.get(1).trim().equals("Chain,0.0,0.0,0.16666666666666666,0.125,0.2,0.16666666666666666,0.14285714285714285,0.1875,0.2777777777777778,0.35,0.5,0.5416666666666666,0.5384615384615384,0.5357142857142857,0.5,0.53125") ?
						new Mark(1, 1): new Mark(0, 1);
			});
			
			mainGrade.addGrading((messages,i)->{
				messages.set(i, "Test n_comparison open");
				return lines.get(2).trim().equals("Open Addressing, 0.0, 0.0, 0.16666666666666666, 0.125, 0.2, 0.16666666666666666, 0.14285714285714285, 0.375, 0.5555555555555556, 0.85, 1.2727272727272727, 1.4166666666666667, 2.0, 2.142857142857143, 2.3666666666666667, 3.0")?
						new Mark(1, 1): new Mark(0, 1);
			});
			BufferedReader brRemove = new BufferedReader(new FileReader(new File("remove_collisions.csv")));
			List<String> linesRemove = new ArrayList<>();
			while((line=brRemove.readLine())!=null) {
				linesRemove.add(line);
			}
			mainGrade.addGrading((messages,i)->{
				messages.set(i,"Test remove_comparison");
				// Allow adding to either list
				return linesRemove.get(1).trim().equals("Chain,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0,1.0,0.0,0.0,0.0,0.0,0.0,1.0") ||
					   linesRemove.get(2).trim().equals("Open Addressing, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0")?
								new Mark(1, 1): new Mark(0, 1);
			});
			
			
			BufferedReader brw = new BufferedReader(new FileReader(new File("w_comparison.csv")));
			List<String> wlines = new ArrayList<>();
			while((line=brw.readLine())!=null) {
				wlines.add(line);
			}
			mainGrade.addGrading((messages, i)->{
				messages.set(i, "Test w_comparison");
				// check for load > 1 open addressing should have more collisions
				String[] splitAlpha = wlines.get(0).trim().split(",");
				int stopIndex = 0;
				for (int n = 1; n < splitAlpha.length; n++) {
					if(Double.parseDouble(splitAlpha[n])>=1) {
						break;
					}
					stopIndex = n;
				}
				String[] chainValues = wlines.get(1).trim().split(",");
				String[] openValues = wlines.get(2).trim().split(",");
				for (int n = 1; n < stopIndex; n++) {
					double chain = Double.parseDouble(chainValues[n] );	
					double open = Double.parseDouble(openValues[n]);
					if(chain>open) return new Mark(0, 1);
				}
				return new Mark(1, 1);
			});
			
			br.close();
			brRemove.close();
			brw.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		mainGrade.grade();
		mainGrade.displayGrades();
		System.out.println("Main "+mainGrade.grade);
		
		System.out.println("Total Score: "+ (probeGrade.reweightedGrade(15).combine(
										chainGrade.reweightedGrade(15).combine(
										chainingInsertGrade.reweightedGrade(15).combine(
										openInsertGrade.reweightedGrade(15).combine(
										openRemoveGrade.reweightedGrade(10).combine(
												mainGrade.reweightedGrade(10))))))));
	}
}
